'''
Date;
Time;
Global_active_power;
Global_reactive_power;
Voltage;
Global_intensity;
Sub_metering_1;
Sub_metering_2;
Sub_metering_3
'''
import numpy as np

HeadDict = {}
with open('household_power_consumption.txt') as f:
    head = next(f).replace("\n", "")
    HeadList = head.split(';')
    
    for h in HeadList:
        HeadDict[h] = []
    
    for i in f:
        i = i.replace("\n", "")
        i = i.split(";")
        if '?' not in i:
            for j in range(len(i)):
                if j < 2:
                    HeadDict[HeadList[j]].append(i[j])
                else:
                    HeadDict[HeadList[j]].append(float(i[j]))

np.save('household_power_consumption', HeadDict)

print(len(HeadDict['Date']))
print(len(HeadDict['Time']))
print(len(HeadDict['Global_active_power']))
print(len(HeadDict['Global_reactive_power']))
print(len(HeadDict['Voltage']))
print(len(HeadDict['Global_intensity']))
print(len(HeadDict['Sub_metering_1']))
print(len(HeadDict['Sub_metering_2']))
print(len(HeadDict['Sub_metering_3']))


#read = np.load('household_power_consumption.npy').item()
#print(len(read['Date']))