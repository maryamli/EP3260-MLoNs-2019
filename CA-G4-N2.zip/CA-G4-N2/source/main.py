'''
Date;
Time;
Global_active_power;

Global_reactive_power;
Voltage;
Global_intensity;
Sub_metering_1;
Sub_metering_2;
Sub_metering_3
'''


import matplotlib.pyplot as plt 
import numpy as np 
from astropy.constants.codata2010 import alpha
np.random.seed(0)
household = np.load('household_power_consumption.npy').item()
import time 

def f(W, Lambda):
    return 1/N*np.sum(np.log(1+np.exp(-y*x.dot(W)))) + Lambda*(np.linalg.norm(W))**2 

def diffW(W, Lambda):
    return -1/N*np.sum(1/(1 + np.exp(-y*x.dot(W)))) + Lambda*(W)*2 

def SG(W,y_,x_, Lambda):
    N_batch = y_.shape[0]
    return -1/N_batch*np.sum(1/(1 + np.exp(-y_*x_.dot(W)))) + Lambda*(W)*2 


def plotHist(X,Y, figureNr, saveTo, xlabel , ylabel, Lambda, meth):
    f1 = plt.figure(figureNr)
    plt.plot(X,Y)
    plt.xlabel(xlabel = xlabel)
    plt.ylabel(ylabel = ylabel)
    plt.grid(True)
    #plt.title(label = 'Method: ' + meth +', Lambda: ' + str(Lambda) + ', ' + 'Alpha: ' + str(Alpha))
    plt.title(label = 'Method: ' )
    f1.savefig(saveTo, bbox_inches='tight')


def plotMultiHist(X, val, figureNr, saveTo, xlabel , ylabel, Lambda):
    f1 = plt.figure(figureNr)
    for X_batch in X:
        plt.plot(X_batch[0],X_batch[1])
    plt.legend(val)
    plt.xlabel(xlabel = xlabel)
    plt.ylabel(ylabel = ylabel)
    plt.grid(True)
    plt.title(label = 'Lambda: ' + str(Lambda) + ', ' + 'Alpha: ' + str(Alpha))
    f1.savefig(saveTo, bbox_inches='tight')

def createBatch(splitIn):
    BatchList_x = np.array_split(x, splitIn)
    BatchList_y = np.array_split(y, splitIn)
    return BatchList_x, BatchList_y



N = len(household['Date'])
ArrayShape = (N,1)
y  = np.asarray(household['Global_active_power']).reshape(ArrayShape)
x1 = np.asarray(household['Global_reactive_power']).reshape(ArrayShape)
x2 = np.asarray(household['Voltage']).reshape(ArrayShape)
x3 = np.asarray(household['Global_intensity']).reshape(ArrayShape)
x4 = np.asarray(household['Sub_metering_1']).reshape(ArrayShape)
x5 = np.asarray(household['Sub_metering_2']).reshape(ArrayShape)
x6 = np.asarray(household['Sub_metering_3']).reshape(ArrayShape)

#print(x1,'\n\n',x2,'\n\n',x3,'\n\n',x4,'\n\n',x5,'\n\n',x6,'\n\n')
# x = 
# [x1[0] x2[0] x3[0].....]
# [x1[1] x2[1] x3[1].....]
# [x1[2] ..... you get the drift]
#
# x.shape = (2049280, 6)
x =  np.concatenate((x1, x2, x3, x4, x5, x6), axis = 1)

# w = 
# [[0.5488135]
# [0.71518937]
# [0.60276338]
# [0.54488318]
# [0.4236548 ]
# [0.64589411]] with seed(0)




#######################
# GD Homebrew
#######################

LambdaList = [0.1, 1, 2, 3] 
Alpha = 0.01

for Lambda in LambdaList:
    np.random.seed(0)
    w  = np.random.rand(x.shape[1],1)
    TrainingHist = [[],[]]
    for iter_ in range(500):
        gradients = diffW(W = w, Lambda = Lambda)
        w = w - Alpha* gradients 
        if iter_%10 == 0:
            TrainingHist[0].append(iter_)
            TrainingHist[1].append(f(W = w, Lambda = Lambda))
            print('iter_:', iter_, 'Cost:', f(W = w, Lambda = Lambda))
            
    #plt.plot(X=TrainingHist[0], Y = TrainingHist[1])
    #plt.show()
    
    plotHist(Lambda = Lambda , meth ='GD' ,X=TrainingHist[0], Y = TrainingHist[1], figureNr = int(Lambda), saveTo = 'fig/GD_Lambda' +str(Lambda) + '.pdf', xlabel='Iterations', ylabel='Cost')
    #time.sleep(5)
#######################
# SGD Homebrew
#######################
'''
LambdaList = [0.1, 1, 2, 3] 
Alpha = 0.01
s = 1e3


BatchList_x, BatchList_y = createBatch(s)
for Lambda in LambdaList:
    np.random.seed(0)
    w  = np.random.rand(x.shape[1],1)
    TrainingHist = [[],[]]
    for iter_ in range(500):
        rndVal = np.random.randint(0,s)
        gradients = SG(W = w,y_ = BatchList_y[rndVal],x_ = BatchList_x[rndVal], Lambda = Lambda)
        w = w - Alpha* gradients 
        if iter_%10 == 0:
            TrainingHist[0].append(iter_)
            TrainingHist[1].append(f(W = w,Lambda = Lambda))
            print('iter_:', iter_, 'Cost:', f(W = w, Lambda = Lambda))

    plotHist(Lambda = Lambda , meth ='SGD' ,X=TrainingHist[0], Y = TrainingHist[1], figureNr = int(Lambda), saveTo = 'fig/SGD_Lambda' +str(Lambda) + '.pdf', xlabel='Iterations', ylabel='Cost')
'''
#######################
# SVRG
#######################
'''
def get_df(w_, Lambda_):
    return -1/N*np.sum(1/(1 + np.exp(-y*x.dot(w_)))) + Lambda_*(w_)*2 

def get_dR(w_ ,y_,x_, Lambda_):
    N_batch = y_.shape[0]
    return -1/N_batch*np.sum(1/(1 + np.exp(-y_*x_.dot(w_)))) + Lambda_*(w_)*2 

def Get_dRList(w,bx, by, Lambda_):
    #Compute the batch gradient ∇R n (w k )
    dRList = []
    for i in range(len(by)):
        dRList.append(get_dR(w_ = w,y_ = by[i],x_ = bx[i], Lambda_ = Lambda_))
    
    return dRList


splitIn = 1e3
Alpha = 0.01
LambdaList = [0.1, 1, 2, 3]
for Lambda in LambdaList:
    np.random.seed(0)
    w  = np.random.rand(x.shape[1],1)
    BatchList_x, BatchList_y = createBatch(splitIn)
    TrainingHist = [[],[]]
    for iter_ in range(100):
        dR_List = Get_dRList(w = w, bx = BatchList_x, by = BatchList_y, Lambda_ = Lambda)
        #print(len(dR_List))
        wj = np.copy(w)
        for j in range(10):
            #Chose i j uniformly from {1, . . . , n}.
            rndVal = np.random.randint(0,len(dR_List))
            # Set g̃ j ← ∇f i j ( w̃ j ) − (∇f i j (w k ) − ∇R n (w k )).
            grad_j = get_df(w_ = wj, Lambda_ = Lambda) -(get_df(w_ = w, Lambda_ = Lambda) - dR_List[rndVal])
            wj = wj - Alpha*grad_j
        # Option (a) Set w k+1 = w̃ m+1
        w = np.copy(wj)  
        #if iter_%10 == 0:
        TrainingHist[0].append(iter_)
        TrainingHist[1].append(f(W = w, Lambda = Lambda))
        print('iter_:', iter_, 'Cost:', f(W = w, Lambda = Lambda))
          
    plotHist(Lambda = Lambda , meth ='SVRG' ,X=TrainingHist[0], Y = TrainingHist[1], figureNr = int(Lambda), saveTo = 'fig/SVRG_Lambda' +str(Lambda) + '.pdf', xlabel='Iterations', ylabel='Cost')
 
'''

#######################
# SAGA
#######################
'''
def get_df(w_, Lambda_):
    return -1/N*np.sum(1/(1 + np.exp(-y*x.dot(w_)))) + Lambda_*(w_)*2 

def get_dR(w_ ,y_,x_, Lambda_):
    N_batch = y_.shape[0]
    return -1/N_batch*np.sum(1/(1 + np.exp(-y_*x_.dot(w_)))) + Lambda_*(w_)*2 

def Get_dRList(w,bx, by, Lambda_):
    #Compute the batch gradient ∇R n (w k )
    dRList = []
    for i in range(len(by)):
        dRList.append(get_dR(w_ = w,y_ = by[i],x_ = bx[i], Lambda_ = Lambda_))
    
    return dRList




LambdaList = [0.1, 1, 1.1]
Alpha = 0.01
count = 1
for Lambda in LambdaList:
    TrainingHist = [[],[]]
    # Choose an initial iterate w 1 ∈ R d and stepsize α > 0
    np.random.seed(0)
    w  = np.random.rand(x.shape[1],1)
    
    #for i = 1, . . . , n do
    #Compute ∇f i (w 1 ).
    #Store ∇f i (w [i] ) ← ∇f i (w 1 ).
    splitIn = 1000
    BatchList_x, BatchList_y = createBatch(splitIn)
    dRList = Get_dRList( w = w, bx = BatchList_x, by = BatchList_y, Lambda_ = Lambda)
    
    for k in range(500):
        #Choose j uniformly in {1, . . . , n}.
        j = np.random.randint(0,len(dRList))
        # Compute ∇f j (w k ).
        fj = get_df(w_ = w, Lambda_ = Lambda)
        #Set g k ← ∇f j (w k ) − ∇f j (w [j] ) + n 1 i=1 ∇f i (w [i] ).
        gk = fj - dRList[j] + 1/len(dRList) * np.sum(dRList)
        dRList[j] = w
        w = w - Alpha * gk
        TrainingHist[0].append(k)
        TrainingHist[1].append(f(W = w, Lambda = Lambda))
        print('Iter:', k, 'Cost:', f(W = w , Lambda = Lambda))
    
         
    plotHist(Lambda = Lambda , meth ='SARA' ,X=TrainingHist[0], Y = TrainingHist[1], figureNr = count, saveTo = 'fig/SARA_Lambda' +str(Lambda) + '.pdf', xlabel='Iterations', ylabel='Cost')
    count += 1

'''